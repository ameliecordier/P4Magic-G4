package model;

/**
 * Created by Cygneis on 17/06/2016.
 */
public class AddPionEffect extends Effect {

    /**
     * Rajoute un pion de la couleur courante dans chaque colonne
     * @param line
     * @param column
     * @param game
     */
    @Override
    public void playEffect (int line, int column, Game game){
        int tile_id = game.getBoard().getTileIJ(line, column).getStatus();
        int player1_id = game.getPlayer1().getId();
        int player2_id = game.getPlayer2().getId();

        if (tile_id == player1_id) {
            tile_id = player2_id;
        } else {
            tile_id = player1_id;
        }

        for (int i = 0; i < game.getBoard().getWidth(); i++) {
            game.playMove(i);
        }
    }
}
