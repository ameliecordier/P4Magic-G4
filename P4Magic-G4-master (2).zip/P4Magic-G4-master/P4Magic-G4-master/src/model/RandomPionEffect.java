package model;

/**
 *
 * @author p1506391
 */
public class RandomPionEffect extends Effect{

    
    /**
     * 
     *Est CENSE générer un pion aléatoirement dans la grille
     */
    @Override
    public void playEffect(int line, int column, Game game) {
       int randomWidth = (int)(Math.random()*(game.getBoard().getWidth()+1));
       int randomPlayer = (int)(Math.random()*((2-1)+1));
       int i = 0;
       while (i != game.getBoard().getHeight()){
           while (game.getBoard().getTileIJ(i, randomWidth).getStatus() != -1){
               i = i+1;
           }
       }
       game.getBoard().getTileIJ(i, randomWidth).setStatus(randomPlayer);
    }

   
    
}
