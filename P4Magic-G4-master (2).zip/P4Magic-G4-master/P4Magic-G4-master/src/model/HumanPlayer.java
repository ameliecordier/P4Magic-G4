/**
 * MagicP4
 * IUT Lyon 1 - 2016
 */
package model;

import java.awt.Color;

/**
 * Class HumanPlayer
 * @author hakkahi - IUT Lyon 1 - 2016
 */
public class HumanPlayer extends Player {

    public HumanPlayer(int id, Color color) {
        super(id, color);
    }

}
